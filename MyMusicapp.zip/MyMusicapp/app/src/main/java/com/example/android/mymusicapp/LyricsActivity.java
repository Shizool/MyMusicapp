package com.example.android.mymusicapp;

public class LyricsActivity {
}
